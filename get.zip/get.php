<?php

$username=($_GET['username']);

$password=($_GET['password']);

$gender=($_GET['gender']);

echo "Username:".$username."<br>";

echo "Password:".$password."<br>";

echo "Gender:".$gender."<br>";

?>