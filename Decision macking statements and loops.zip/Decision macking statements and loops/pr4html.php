<!DOCTYPE html>
<html>
<head>
    <title>Car Company Finder</title>
</head>
<body>
    <h1>Find the Car Company</h1>
    <form action="pr4.php" method="get">
        <label for="carName">Enter the name of the car:</label>
        <input type="text" id="carName" name="carName" required>
        <button type="submit">Find Company</button>
    </form>
</body>
</html>