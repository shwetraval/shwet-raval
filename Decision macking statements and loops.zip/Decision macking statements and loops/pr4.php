<?php
$cars = [
    "Safari" => "Tata",
    "Nexon" => "Tata",
    "Tigor" => "Tata",
    "Tiago" => "Tata",
    "XUV700" => "Mahindra",
    "XUV300" => "Mahindra",
    "Bolero" => "Mahindra",
    "i20" => "Hyundai",
    "Verna" => "Hyundai",
    "Venue" => "Hyundai",
    "Creta" => "Hyundai",
    "Swift" => "Suzuki",
    "Alto" => "Suzuki",
    "Baleno" => "Suzuki",
    "Brezza" => "Suzuki"
];


if (isset($_GET['carName'])) {

    $carName = $_GET['carName'];


    if (array_key_exists($carName, $cars)) {
        echo "<p>The car <strong>$carName</strong> belongs to <strong>" . $cars[$carName] . "</strong>.</p>";
    } else {
        echo "<p>Car not found in the list.</p>";
    }
} else {
    echo "<p>No car name provided.</p>";
}
?>