<?php

$username=($_POST['username']);

$password=($_POST['password']);

$gender=($_POST['gender']);

echo "Username:".$username."<br>"; echo "Password:".$password."<br>"; echo "Gender:".$gender."<br>";

?>