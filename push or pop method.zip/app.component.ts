import { RouterOutlet } from '@angular/router';
import { Component } from '@angular/core';
import { CommonModule} from '@angular/common';

@Component
({
selector: 'app-root',
standalone: true,
imports: [RouterOutlet,CommonModule],
templateUrl: './app.component.html',
styleUrl: './app.component.css'
})

export class AppComponent 
{
  title = '';
  studentList: any = [
    {firstname: 'shwet ', roll_no: '01', address: 'Botad'},
    {firstname: 'sumit', roll_no: '02', address: 'Surendranagar'},
    {firstname: 'snehil', roll_no: '03', address: 'Rajkot'},
    {firstname: 'Aaditya', roll_no: '04', address: 'Botad'},
    {firstname: 'sidhharth', roll_no: '05', address: 'Viramgam' },
    {firstname: 'dakshil', roll_no: '06', address: 'Gadhada' }
  ];
  constructor() 
  {

  }
  ngOnInit(): void 
  {

  }
  addstudent() 
  {

  }
  remove(index: any) 
  {
    this.studentList.splice(index, 1)
  }
}