<div class="copyrights">
	 <p>TMS. All Rights Reserved |  <a href="#">TMS</a> </p>
</div>	
